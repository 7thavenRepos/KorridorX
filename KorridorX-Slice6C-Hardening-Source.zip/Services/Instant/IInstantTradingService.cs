using KorridorX.Dtos.Instant;
using KorridorX.Infrastructure;
using KorridorX.Models.Enums;

namespace KorridorX.Services.Instant;

public interface IInstantTradingService
{
    Task<IReadOnlyList<InstantPairDto>> GetPairsAsync(CancellationToken ct = default);
    Task<InstantQuoteDto> CreateQuoteAsync(Guid userId, CreateInstantQuoteRequestDto request, CancellationToken ct = default);
    Task<InstantTradeDto> ExecuteQuoteAsync(Guid userId, Guid quoteId, CancellationToken ct = default);
    Task<PagedResult<InstantTradeDto>> GetMyTradesAsync(Guid userId, int page = 1, int pageSize = 20, CancellationToken ct = default);

    Task<InstantPairDto> CreatePairAsync(Guid actionedByUserId, CreateInstantPairRequestDto request, CancellationToken ct = default);
    Task<InstantPairDto> UpdatePairAsync(Guid actionedByUserId, Guid pairId, UpdateInstantPairRequestDto request, CancellationToken ct = default);
    Task<InstantPairDto> SetPairStatusAsync(Guid actionedByUserId, Guid pairId, InstantPairStatus status, CancellationToken ct = default);
}
