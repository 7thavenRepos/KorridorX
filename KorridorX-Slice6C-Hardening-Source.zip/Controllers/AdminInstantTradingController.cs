using System.Security.Claims;
using KorridorX.Dtos.Instant;
using KorridorX.Infrastructure;
using KorridorX.Models.Enums;
using KorridorX.Services.Instant;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace KorridorX.Controllers;

[ApiController]
[Authorize(Roles = "Admin,SuperAdmin,Operations")]
[Route("api/admin/instant")]
public sealed class AdminInstantTradingController : ControllerBase
{
    private readonly IInstantTradingService _service;

    public AdminInstantTradingController(IInstantTradingService service)
    {
        _service = service;
    }

    [HttpPost("pairs")]
    public async Task<IActionResult> CreatePair(
        [FromBody] CreateInstantPairRequestDto request,
        CancellationToken ct) =>
        Ok(ApiResponses.Ok(
            await _service.CreatePairAsync(GetUserId(), request, ct),
            "Instant trading pair created successfully."));

    [HttpPut("pairs/{pairId:guid}")]
    public async Task<IActionResult> UpdatePair(
        Guid pairId,
        [FromBody] UpdateInstantPairRequestDto request,
        CancellationToken ct) =>
        Ok(ApiResponses.Ok(
            await _service.UpdatePairAsync(GetUserId(), pairId, request, ct),
            "Instant trading pair updated successfully."));

    [HttpPut("pairs/{pairId:guid}/status")]
    public async Task<IActionResult> SetPairStatus(
        Guid pairId,
        [FromBody] SetInstantPairStatusRequestDto request,
        CancellationToken ct) =>
        Ok(ApiResponses.Ok(
            await _service.SetPairStatusAsync(GetUserId(), pairId, request.Status, ct),
            "Instant trading pair status updated successfully."));

    private Guid GetUserId()
    {
        var value = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.TryParse(value, out var id)
            ? id
            : throw new UnauthorizedAccessException("Invalid authenticated user.");
    }
}
