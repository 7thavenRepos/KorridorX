using KorridorX.Models.Enums;

namespace KorridorX.Dtos.Instant;

public record InstantPairDto(
    Guid Id,
    string Code,
    string SourceAssetCode,
    string DestinationAssetCode,
    InstantPairStatus Status,
    decimal MinimumSourceAmount,
    decimal? MaximumSourceAmount,
    decimal SourceAmountIncrement,
    int QuoteValiditySeconds);

public record CreateInstantPairRequestDto(
    string SourceAssetCode,
    string DestinationAssetCode,
    Guid HouseSourceFinancialAccountId,
    Guid HouseDestinationFinancialAccountId,
    decimal MinimumSourceAmount,
    decimal? MaximumSourceAmount,
    decimal SourceAmountIncrement,
    int QuoteValiditySeconds = 30,
    InstantPairStatus Status = InstantPairStatus.Paused);

public record UpdateInstantPairRequestDto(
    Guid HouseSourceFinancialAccountId,
    Guid HouseDestinationFinancialAccountId,
    decimal MinimumSourceAmount,
    decimal? MaximumSourceAmount,
    decimal SourceAmountIncrement,
    int QuoteValiditySeconds);

public record SetInstantPairStatusRequestDto(InstantPairStatus Status);

public record CreateInstantQuoteRequestDto(
    Guid InstantPairId,
    decimal SourceAmount);

public record InstantQuoteDto(
    Guid Id,
    string Reference,
    Guid InstantPairId,
    string PairCode,
    string SourceAssetCode,
    string DestinationAssetCode,
    decimal SourceAmount,
    decimal DestinationAmount,
    decimal CustomerRate,
    DateTime ExpiresAt,
    InstantQuoteStatus Status);

public record ExecuteInstantQuoteRequestDto(Guid QuoteId);

public record InstantTradeDto(
    Guid Id,
    string Reference,
    Guid InstantQuoteId,
    Guid InstantPairId,
    string PairCode,
    string SourceAssetCode,
    string DestinationAssetCode,
    decimal SourceAmount,
    decimal DestinationAmount,
    decimal CustomerRate,
    InstantTradeStatus Status,
    DateTime CreatedAt,
    DateTime? CompletedAt);
