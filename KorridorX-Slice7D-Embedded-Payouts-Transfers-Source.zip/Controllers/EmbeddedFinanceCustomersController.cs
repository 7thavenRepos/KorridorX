using KorridorX.Dtos.EmbeddedFinance;
using KorridorX.Infrastructure;
using KorridorX.Services.EmbeddedFinance;
using Microsoft.AspNetCore.Mvc;

namespace KorridorX.Controllers;
[ApiController, Route("api/v1/embedded/customers")]
public sealed class EmbeddedFinanceCustomersController : ControllerBase
{
    private readonly IEmbeddedFinanceCustomerService _service;
    private readonly ICollectionAccountProvisioningService _provisioning;
    public EmbeddedFinanceCustomersController(
        IEmbeddedFinanceCustomerService service,
        ICollectionAccountProvisioningService provisioning)
    {
        _service = service;
        _provisioning = provisioning;
    }
    [HttpGet] public async Task<IActionResult> Customers([FromQuery]int page=1,[FromQuery]int pageSize=50,CancellationToken ct=default){var r=await _service.GetCustomersAsync(page,pageSize,ct);return Ok(ApiResponses.OkPaged(r.Items,r.Meta,"Business customers retrieved successfully."));}
    [HttpPost] public async Task<IActionResult> CreateCustomer([FromHeader(Name="Idempotency-Key")]string? key,[FromBody]CreateBusinessCustomerRequestDto request,CancellationToken ct)=>Ok(ApiResponses.Ok(await _service.CreateCustomerAsync(request,key??"",ct),"Business customer created successfully."));
    [HttpGet("{businessCustomerId:guid}/accounts")] public async Task<IActionResult> Accounts(Guid businessCustomerId,CancellationToken ct)=>Ok(ApiResponses.Ok(await _service.GetAccountsAsync(businessCustomerId,ct),"Collection accounts retrieved successfully."));
    [HttpPost("{businessCustomerId:guid}/accounts")] public async Task<IActionResult> CreateAccount(Guid businessCustomerId,[FromHeader(Name="Idempotency-Key")]string? key,[FromBody]CreateCollectionAccountRequestDto request,CancellationToken ct)=>Ok(ApiResponses.Ok(await _service.CreateAccountAsync(businessCustomerId,request,key??"",ct),"Collection account created successfully."));
    [HttpGet("{businessCustomerId:guid}/accounts/{collectionAccountId:guid}/provider-mappings")]
    public async Task<IActionResult> ProviderMappings(Guid businessCustomerId, Guid collectionAccountId, CancellationToken ct) =>
        Ok(ApiResponses.Ok(await _provisioning.GetMappingsAsync(businessCustomerId, collectionAccountId, ct),
            "Provider account mappings retrieved successfully."));

    [HttpPost("{businessCustomerId:guid}/accounts/{collectionAccountId:guid}/provision")]
    public async Task<IActionResult> Provision(
        Guid businessCustomerId,
        Guid collectionAccountId,
        [FromBody] ProvisionCollectionAccountRequestDto request,
        CancellationToken ct) =>
        Ok(ApiResponses.Ok(await _provisioning.ProvisionAsync(businessCustomerId, collectionAccountId, request, ct),
            "Provider collection account provisioned successfully."));
}
