using System.Text.Json;
using KorridorX.Data;
using KorridorX.Models.EmbeddedFinance;
using KorridorX.Models.Enums;
using Microsoft.EntityFrameworkCore;

namespace KorridorX.Services.EmbeddedFinance;

public sealed class EmbeddedWebhookPublisher : IEmbeddedWebhookPublisher
{
    private readonly AppDbContext _db;
    public EmbeddedWebhookPublisher(AppDbContext db) => _db = db;

    public async Task<Guid> PublishAsync(Guid businessProfileId, string eventType, object payload, CancellationToken ct = default)
    {
        var normalizedType = (eventType ?? "").Trim().ToLowerInvariant();
        if (normalizedType.Length == 0 || normalizedType.Length > 150)
            throw new InvalidOperationException("Webhook event type is invalid.");

        var now = DateTime.UtcNow;
        var evt = new BusinessWebhookEvent
        {
            BusinessProfileId = businessProfileId,
            EventId = $"evt_{Guid.NewGuid():N}",
            EventType = normalizedType,
            PayloadJson = JsonSerializer.Serialize(payload),
            OccurredAt = now
        };

        var endpoints = await _db.BusinessWebhookEndpoints.AsNoTracking()
            .Where(x =>
                x.BusinessProfileId == businessProfileId &&
                x.Status == BusinessWebhookEndpointStatus.Active &&
                !x.IsDeleted)
            .ToListAsync(ct);

        foreach (var endpoint in endpoints.Where(x => Matches(x.EventTypesCsv, normalizedType)))
            evt.Deliveries.Add(new BusinessWebhookDelivery
            {
                BusinessWebhookEndpointId = endpoint.Id,
                Status = BusinessWebhookDeliveryStatus.Pending,
                NextAttemptAt = now
            });

        _db.BusinessWebhookEvents.Add(evt);
        await _db.SaveChangesAsync(ct);
        return evt.Id;
    }

    private static bool Matches(string csv, string eventType)
    {
        if (string.IsNullOrWhiteSpace(csv)) return false;
        var values = csv.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        return values.Any(x => x == "*" || x.Equals(eventType, StringComparison.OrdinalIgnoreCase));
    }
}
