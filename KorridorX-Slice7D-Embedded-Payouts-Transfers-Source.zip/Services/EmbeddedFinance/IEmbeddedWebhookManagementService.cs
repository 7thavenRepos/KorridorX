using KorridorX.Dtos.EmbeddedFinance;

namespace KorridorX.Services.EmbeddedFinance;

public interface IEmbeddedWebhookManagementService
{
    Task<IReadOnlyList<BusinessWebhookEndpointDto>> GetEndpointsAsync(Guid userId, CancellationToken ct = default);
    Task<BusinessWebhookEndpointCreatedDto> CreateEndpointAsync(Guid userId, CreateBusinessWebhookEndpointRequestDto request, CancellationToken ct = default);
    Task<RotateBusinessWebhookSecretDto> RotateSecretAsync(Guid userId, Guid endpointId, CancellationToken ct = default);
    Task SetStatusAsync(Guid userId, Guid endpointId, bool enabled, CancellationToken ct = default);
}
